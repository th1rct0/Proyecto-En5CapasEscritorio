﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using Entidades;
using System.Runtime.Remoting.Messaging;

namespace Datos
{
    public class D_Customer : CAD //tener acceso a la clase DEBSAccesoDatos para conectarnos a la base de datos
    {
        public DataSet GetAll()// Method to retrieve all customers
        {
            DataSet dataSet = new DataSet();
            DataSet DS = dataSet;

            try
            {


                SqlCommand cmd = CrearComando("Customer_Get");// Create a SqlCommand to execute the stored procedure "Customer_Get"
                DS = GetDS(cmd, "Customer_Get");// Execute the command and get the DataSet

            }
            catch (SqlException Ex)// Catch any exceptions that occur during the process

            {
                throw new Exception("Error Obteniendo todos los registros en D_CUSTOMER   " + Ex.Message, Ex);

            }




            return DS;
        }

        public E_Customer GetOne(int CustomerId)
        {
            E_Customer vRes = new E_Customer();

            SqlCommand cmd = new SqlCommand();
            try
            {
                cmd = CrearComando("Customer_Get");
                cmd.Parameters.AddWithValue("@CustomerId", CustomerId);
                AbrirConexion();
                SqlDataReader consulta = Ejecuta_Consulta(cmd);
                if (consulta.Read())
                {
                    if (consulta.HasRows)
                    {
                        vRes.CustomerId = (int)consulta["CustomerId"];
                        vRes.NameStyle = (Boolean)consulta["NameStyle"];/*//Boolean no puede ser null. con B mayuscula Más común en código que usa reflexión o interoperabilidad
                                                                            Tiene métodos como Parse(), ToString(), etc.Pertenece a System*/

                        vRes.Title = (string)consulta["Title"]; //puede ser null
                        vRes.FirstName = (string)consulta["FirstName"];
                        vRes.MiddleName = Convert.ToString(consulta["MiddleName"]);
                        vRes.LastName = (string)consulta["LastName"];
                        vRes.Suffix = Convert.ToString(consulta["Suffix"]);
                        vRes.CompanyName = Convert.ToString(consulta["CompanyName"]);
                        vRes.SalesPerson = Convert.ToString(consulta["SalesPerson"]);
                        vRes.EmailAddress = Convert.ToString(consulta["EmailAddress"]);
                        vRes.Phone = Convert.ToString(consulta["Phone"]);
                        vRes.PasswordHash = (string)consulta["PasswordHash"];
                        vRes.PasswordSalt = (string)consulta["PasswordSalt"];
                        vRes.ModifiedDate = (DateTime)consulta["ModifiedDate"];
                    }
                }
                //   return vRes;
                consulta.Close();
                consulta.Dispose();

            }
            catch (SqlException Ex)
            {
                throw new Exception("Error Obteniendo un registro en D_CUSTOMER   " + Ex.Message, Ex);
            }
            finally { 
                cmd.Dispose();
                CerrarConexion();
            }
            return vRes;
        }
    }
}

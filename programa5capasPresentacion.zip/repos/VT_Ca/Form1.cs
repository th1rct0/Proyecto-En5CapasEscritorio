﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
using Entidades;


namespace VT_Ca
{
    public partial class Form1 : Form
    {
        P_Customer oCliente = new P_Customer();
        E_Customer oCliente_Ent = new E_Customer();//instancia de la clase entidad
        public Form1()
        {
            InitializeComponent();
        }
        private void IniDG()  // COn INidg se llena el datagridview
        {

            try
            {

                DGCustomer.DataSource = oCliente.GetAll().Tables[0];
                DGCustomer.Refresh();

            }
            catch (Exception Ex)
            {
                MessageBox.Show("Formulario--->   " +Ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            IniDG();
        }

        private void txtCustomerId_KeyPress(object sender, KeyPressEventArgs e)
        {//cuando tecleas enter en el textbox
            if (e.KeyChar == (char)Keys.Return)
            {   int CusId= Convert.ToInt32(txtCustomerId.Text);

                try
                {
                    oCliente_Ent = oCliente.GetOne(CusId);
                    chkNamSTyle.Checked = oCliente_Ent.NameStyle;
                    txtTitle.Text = oCliente_Ent.Title;
                    txtFirstName.Text = oCliente_Ent.FirstName;
                    txtMiddleName.Text = oCliente_Ent.MiddleName;
                    txtLastName.Text = oCliente_Ent.LastName;
                    txtSuffiix.Text = oCliente_Ent.Suffix;
                    txtCompanyName.Text = oCliente_Ent.CompanyName;
                   textBoxtxtSalesPerson.Text = oCliente_Ent.SalesPerson;
                    txtEmailAddress.Text = oCliente_Ent.EmailAddress;
                    txtPhone.Text = oCliente_Ent.Phone;
                    txtPasswordhash.Text = oCliente_Ent.PasswordHash;
                    txtPasswordSalt.Text = oCliente_Ent.PasswordSalt;


                }
                catch(Exception Ex)
                {
                    MessageBox.Show("TextBox--->   " + Ex.Message);
                }
                
            }
        }
    }
}

